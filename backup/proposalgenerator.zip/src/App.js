import React from "react";
import { Switch , Route} from 'react-router-dom';
import Table from "./components/Dashboard/Table";
import { BrowserRouter as Router } from 'react-router-dom';
import NewProposal from "./components/NewProposal";

function App() {

  return (
    <div>
      <Router>
      <Switch>
        {/* <Route exact path="/">
          <Redirect exact from="/" to="/auth/login" />
        </Route> */}
        <Route exact path="/">
          <Table />
        </Route>
        <Route path="/new-proposal">
          <NewProposal />
        </Route>
      </Switch>
      </Router>
    </div>
    )
}

export default App;