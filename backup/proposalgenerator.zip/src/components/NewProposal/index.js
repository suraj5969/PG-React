import React from 'react';
import Header from './Globals/Header';
import CssBaseline from '@mui/material/CssBaseline';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import SubTabs from './SubTabs';
import ClientInfo from './ClientInfo';
import { addDays } from 'date-fns';
// import saveProposalAPI from '../../apis/saveProposalAPI';
import InfoPopup from './PopUps/InfoPopup';
import './NewProposal.css';

export default function NewProposal() {

    const defaultClientProfile = {
        clientName: '',
        clientNumber: '',
        opportunityNumber: '',
        opportunityName: '',
        numOfUsers: '', // interger field processed as integer in code
        numOfFreeEarners: '', //integer field
        country: '',
        objective: '',
        commercialObjective: '',
        upsell: '',
        solutionSpecialistId: '', // set to current user
        quickStart: 'No',
        currentSoftware: '',
        endValidDate: addDays(new Date(), 30),
        duration: '',
        address: '',
    }
    const [clientProfile, setClientProfile] = React.useState(defaultClientProfile);

    const defaultInfo = {
        hoursRequired: '', //integer field
        timeIncluded: 'No',
        traningMethod: 'Blended Learning',
        bpaSetup: 'Standard',
        specialConditions: '',
        currency: 'AUD'
    }
    const [Info, setInfo] = React.useState(defaultInfo);


    const defaultAttendingCourses = {
        operationsAdmin: 0,
        dataforms: 0,
        endUserAccount: 0,
        endUserBPA: 0
    }
    const [attendingCourses, setAttendingCourses] = React.useState(defaultAttendingCourses);



    const defaultServicesRow = {
        task: '',
        traningMethod: '',
        team: '',
        include: 'Yes',
        PM: 0,
        TSG: 0,
        accountsTraining: 0,
        accountsConsulting: 0,
        BPAConsulting: 0,
        travel: 0,
        totalHrs: 0
    }

    const defaultServices = {
        projectMgmt: { ...defaultServicesRow, team: 'PM', task: 'Project Management' },
        installationOracle: { ...defaultServicesRow, team: 'TSG', task: 'Installation Oracle and Affinity' },
        essentialsCourse: { ...defaultServicesRow, team: 'ACC', task: 'Essentials Course (max. 6/session)' },
        operationsCourse: { ...defaultServicesRow, team: 'ACC', task: 'Operations Course (max. 6/session)' },
        administrationCourse: { ...defaultServicesRow, team: 'ACC', task: 'Administration Course (max. 6/session)' },
        systemSetup: { ...defaultServicesRow, team: 'ACC', task: 'System Setup & Commence Backprocessing' },
        backprocessing: { ...defaultServicesRow, team: 'ACC', task: 'Backprocessing Assistance' },
        reconcileTakeUp: { ...defaultServicesRow, team: 'ACC', task: 'Reconcile Take Up & Go Live Assistance' },
        anticipatedDisbs: { ...defaultServicesRow, team: 'ACC', task: 'Anticipated Disbs/Creditors/Bank Reconciliation' },
        trainInBillTemp: { ...defaultServicesRow, team: 'ACC', task: 'Train in Bill Templates' },
        endUserTraining: { ...defaultServicesRow, team: 'ACC', task: 'End User Training (Train the Trainer)' },
        endOfMonth: { ...defaultServicesRow, team: 'ACC', task: 'End of Month/Training in Reports' },
        documentMgmt: { ...defaultServicesRow, team: 'BPA', task: 'Document Management Installation & Training' },
        totalHrsBaseInstall: { ...defaultServicesRow, team: '', include: '', task: 'Total Hours for Base Install/Take Up' },
        totalDays: { ...defaultServicesRow, team: '', include: '', task: 'Total Days' },
    }
    const [defaultServicesValues, setDefaultServicesValues] = React.useState(defaultServices);


    const optionalServicesRow = {
        task: '',
        traningMethod: '',
        include: 'No',
        team: '',
        PM: 0,
        TSG: 0,
        dataMigration: 0,
        accountsTraining: 0,
        accountsConsulting: 0,
        BPATraining: 0,
        BPAConsulting: 0,
        travel: 0,
        totalHrs: 0
    }
    const defaultOptionalServices = {
        totalHours: { ...optionalServicesRow, task: 'Total Hours', traningMethod: '', team: '', include: '', },
        totalDays: { ...optionalServicesRow, task: 'Total Days', traningMethod: '', team: '', include: '', },
        grandTotalHours: { ...optionalServicesRow, task: 'Grand Total Hours', traningMethod: '', team: '', include: '', },
        grandTotalDays: { ...optionalServicesRow, task: 'Grand Total Days', traningMethod: '', team: '', include: '', },

        dataMigrationRow: { ...optionalServicesRow, team: 'DM', task: 'Data Migration Required?' },
        selfCustody: { ...optionalServicesRow, team: 'ACC', task: 'Safe Custody Register/Investments' },
        multyPartyBilling: { ...optionalServicesRow, team: 'ACC', task: 'Multi-party billing' },
        reportWriting: { ...optionalServicesRow, team: 'ACC', task: 'Report Writing Course' },
        dataformsMax: { ...optionalServicesRow, team: 'BPA', task: 'Dataforms & Precedents(max. 6/session)' },
        scripting: { ...optionalServicesRow, team: 'BPA', task: 'Scripting(max. 6/session)' },
        workflow: { ...optionalServicesRow, team: 'BPA', task: 'Workflow(max. 6/session)' },
        BPAEndUser: { ...optionalServicesRow, team: 'BPA', task: 'BPA End User Training(max. 6/session)' },
        BPAEssentials: { ...optionalServicesRow, team: 'BPA', task: 'BPA Essentials(max. 6/session)' },
        dataformsPhoneBook: { ...optionalServicesRow, team: 'BPA', task: 'Dataforms & Precedents(Phonebook only)' },
        addPrecedent: { ...optionalServicesRow, team: 'BPA', task: 'Additional precedent configuration' },
        BPAGoLive: { ...optionalServicesRow, team: 'BPA', task: 'BPA Go Live assistance' },
        exchangeIntegration: { ...optionalServicesRow, team: 'TSG/BPA', task: 'Exchange Integration' },
        softdocsIntegration: { ...optionalServicesRow, team: 'BPA', task: 'Softdocs Integration' },
        clientPortal: { ...optionalServicesRow, team: 'TSG/BPA', task: 'Client Portal' },
        worksiteIntegration: { ...optionalServicesRow, team: 'BPA', task: 'Worksite Integration' },
        affinityMobile: { ...optionalServicesRow, team: 'TSG', task: 'Affinity Mobile' },
        empower: { ...optionalServicesRow, team: 'BPA', task: 'Empower' },
        settlementAdjuster: { ...optionalServicesRow, team: 'TSG', task: 'Settlement Adjuster' },
        thirdPartyIT: { ...optionalServicesRow, team: 'TSG', task: 'Third-Party IT resources or infrastructure' },
    }
    const [optionalServices, setOptionalServices] = React.useState(defaultOptionalServices);


    const miscellaneousRow = {
        miscellaneous: '',
        included: 'No',
        hours: 0,
        price: 0
    }
    const defaultMiscellaneous = {
        affinityServer: { ...miscellaneousRow, miscellaneous: 'Affinity Server CPUs', included: '' },
        lexisResearch: { ...miscellaneousRow, miscellaneous: 'Is LexisNexis Research included?', },
        scopingStudy: { ...miscellaneousRow, miscellaneous: 'Is a scoping study required?', },
        additionalReturn: { ...miscellaneousRow, miscellaneous: 'Additional return trips required?', included: 0 },
        propertyPresidency: { ...miscellaneousRow, miscellaneous: 'Property Presidency Pack - NZ', hours: '', price: '' },
    }
    const [miscellaneous, setMiscellaneous] = React.useState(defaultMiscellaneous);

    const date = new Date();
    const defaultNotes = [{
        note_no: 1,
        user_id: 0,
        date: `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`,
        note: '',
        time: `${date.getHours()}:${date.getMinutes()}`,
        user: 'Rahul Nagare'
    }]
    const [notes, setNotes] = React.useState(defaultNotes);

    const upfrontCostRow = {
        label: '',
        cost: 0,
        percentDiscount: 0,
        discountItemcost: 0,
        discountAmount: 0
    }
    const defaultUpfrontCost = {
        softwareDiscount: '',
        serviceDiscount: '',
        lexisServerLicense: { ...upfrontCostRow, label: 'Lexis Affinity Server licence' },
        lexisUserLicense: { ...upfrontCostRow, label: 'Lexis Affinity User licences for users' },
        oracleLicenses: { ...upfrontCostRow, label: 'Oracle licenses' },
        clientPortal: { ...upfrontCostRow, label: 'Client Portal' },
        affinityMobile: { ...upfrontCostRow, label: 'Affinity Mobile' },
        lexisSettleAdjuster: { ...upfrontCostRow, label: 'Lexis Affinity Settlement Adjuster' },
        twoWayMicrosoft: { ...upfrontCostRow, label: '2-Way Microsoft Exchange Integration' },
        empower: { ...upfrontCostRow, label: 'Empower' },
        softDocs: { ...upfrontCostRow, label: 'SoftDocs InterConnect' },

        ImplementServices: { ...upfrontCostRow, label: 'Implementation Services' },
        ImplementTraning: { ...upfrontCostRow, label: 'Implementation Training' },
        postImplementation: { ...upfrontCostRow, label: 'Post-implementation review & assistance' },
        dataMigration: { ...upfrontCostRow, label: 'Data Migration' },
        travelAllowance: { ...upfrontCostRow, label: 'Allowance for Travel' },
        scopingStudy: { ...upfrontCostRow, label: 'Scoping Study' },
        propertyPrecedent: { ...upfrontCostRow, label: 'Property Precedents Pack - NZ' },
        subTotal: { ...upfrontCostRow, label: 'Sub Total' },
        lessConfidential: { ...upfrontCostRow, label: 'Less confidential discount', percentDiscount: 0 },
        totalInvesteExcl: { ...upfrontCostRow, label: 'Total Investment excl. GST', percentDiscount: 0 },
        GSTPayable: { ...upfrontCostRow, label: 'GST Payable 15.0%', percentDiscount: 0 },
        totalInvestePay: { ...upfrontCostRow, label: 'Total Investment: Payable Year 1', percentDiscount: 0 },
        totalPerUser: { ...upfrontCostRow, label: '(Total Per User)', percentDiscount: 0 },
    }
    const [upfrontCost, setUpfrontCost] = React.useState(defaultUpfrontCost);


    const defaultOngoingMnt = {
        annualAffinity: { ...upfrontCostRow, label: 'Annual Affinity Lexis Care' },
        annualOracleCare: { ...upfrontCostRow, label: 'Annual OracleCare for Oracle Licences' },
        annualAffinityMobile: { ...upfrontCostRow, label: 'Annual Affinity Mobile Lexis Care' },
        annualClient: { ...upfrontCostRow, label: 'Annual Client Portal Lexis Care' },
        annualEmpower: { ...upfrontCostRow, label: 'Annual Empower Lexis Care' },
        annualSoftDocs: { ...upfrontCostRow, label: 'Annual SoftDocs InterConnect Lexis Care' },
        annualSettlement: { ...upfrontCostRow, label: 'Annual Settlement Adjuster Lexis Care' },
        subTotal: { ...upfrontCostRow, label: 'Sub Total' },
        lessConfidential: { ...upfrontCostRow, label: 'Less confidential discount', percentDiscount: '-', discountItemcost: '-', discountAmount: '-' },
        totalMntExclGST: { ...upfrontCostRow, label: 'Total Maintenance Fees excl. GST', percentDiscount: '-', discountItemcost: '-', discountAmount: '-' },
        GSTPayable: { ...upfrontCostRow, label: 'GST Payable 0%', percentDiscount: '-', discountItemcost: '-', discountAmount: '-' },
        totalMntAnnual: { ...upfrontCostRow, label: 'Total Maintenance Fees:Annual', percentDiscount: '-', discountItemcost: '-', discountAmount: '-' },
        totalMntMonthly: { ...upfrontCostRow, label: 'Total Maintenance Fees: Monthly', percentDiscount: '-', discountItemcost: '-', discountAmount: '-' },
        totalAnnualCost: { ...upfrontCostRow, label: 'Total Annual Cost For Each User', percentDiscount: '-', discountItemcost: '-', discountAmount: '-' },
        totalCostMonth: { ...upfrontCostRow, label: 'Total Cost Per Month For Each User', percentDiscount: '-', discountItemcost: '-', discountAmount: '-' },
    }
    const [ongoingMnt, setOngoingMnt] = React.useState(defaultOngoingMnt);

    const defaultRepayment = {
        totalsTable: {
            software: { label: 'Software', cost: 0, gcrmEntries: 0, },
            services: { label: 'Services', cost: 0, gcrmEntries: 0, },
            sTotal: { label: 'Total', cost: 0, gcrmEntries: 0, },
            pricePerTool: { label: 'Price per tool', cost: 0, gcrmEntries: 0, },
            priceTotal: { label: 'Total', cost: 0, gcrmEntries: 0, },
        },
        mntTable: {
            year1: { label: 'Year 1', RRP: 0, discounted: 0 },
            year2: { label: 'Year 2', RRP: 0, discounted: 0 },
            year3: { label: 'Year 3', RRP: 0, discounted: 0 },
            year4: { label: 'Year 4', RRP: 0, discounted: 0 },
            year5: { label: 'Year 5', RRP: 0, discounted: 0 },
            mntTotal: { label: 'Total', RRP: 0, discounted: 0 },
        },
        repayments: {
            initPayment: { label: 'Initial Payment', payments: 0, lexisCare: 0 },
            month1: { label: 'Month1', payments: 0, lexisCare: 0 },
            month2: { label: 'Month2', payments: 0, lexisCare: 0 },
            month3: { label: 'Month3', payments: 0, lexisCare: 0 },
            month4: { label: 'Month4', payments: 0, lexisCare: 0 },
            month5: { label: 'Month5', payments: 0, lexisCare: 0 },
            month6: { label: 'Month6', payments: 0, lexisCare: 0 },
            month7: { label: 'Month7', payments: 0, lexisCare: 0 },
            month8: { label: 'Month8', payments: 0, lexisCare: 0 },
            month9: { label: 'Month9', payments: 0, lexisCare: 0 },
            month10: { label: 'Month10', payments: 0, lexisCare: 0 },
            month11: { label: 'Month11', payments: 0, lexisCare: 0 },
            month12: { label: 'Month12', payments: 0, lexisCare: 0 },
            month13: { label: 'Month13', payments: 0, lexisCare: 0 },
            month14: { label: 'Month14', payments: 0, lexisCare: 0 },
            month15: { label: 'Month15', payments: 0, lexisCare: 0 },
            month16: { label: 'Month16', payments: 0, lexisCare: 0 },
            month17: { label: 'Month17', payments: 0, lexisCare: 0 },
            month18: { label: 'Month18', payments: 0, lexisCare: 0 },
            month19: { label: 'Month19', payments: 0, lexisCare: 0 },
            month20: { label: 'Month20', payments: 0, lexisCare: 0 },
            month21: { label: 'Month21', payments: 0, lexisCare: 0 },
            month22: { label: 'Month22', payments: 0, lexisCare: 0 },
            month23: { label: 'Month23', payments: 0, lexisCare: 0 },
            month24: { label: 'Month24', payments: 0, lexisCare: 0 },
            month25: { label: 'Month25', payments: 0, lexisCare: 0 },
            month26: { label: 'Month26', payments: 0, lexisCare: 0 },
            month27: { label: 'Month27', payments: 0, lexisCare: 0 },
            month28: { label: 'Month28', payments: 0, lexisCare: 0 },
            month29: { label: 'Month29', payments: 0, lexisCare: 0 },
            month30: { label: 'Month30', payments: 0, lexisCare: 0 },
            month31: { label: 'Month31', payments: 0, lexisCare: 0 },
            month32: { label: 'Month32', payments: 0, lexisCare: 0 },
            month33: { label: 'Month33', payments: 0, lexisCare: 0 },
            month34: { label: 'Month34', payments: 0, lexisCare: 0 },
            month35: { label: 'Month35', payments: 0, lexisCare: 0 },
            month36: { label: 'Month36', payments: 0, lexisCare: 0 },
            month37: { label: 'Month37', payments: 0, lexisCare: 0 },
            month38: { label: 'Month38', payments: 0, lexisCare: 0 },
            month39: { label: 'Month39', payments: 0, lexisCare: 0 },
            month40: { label: 'Month40', payments: 0, lexisCare: 0 },
            month41: { label: 'Month41', payments: 0, lexisCare: 0 },
            month42: { label: 'Month42', payments: 0, lexisCare: 0 },
            month43: { label: 'Month43', payments: 0, lexisCare: 0 },
            month44: { label: 'Month44', payments: 0, lexisCare: 0 },
            month45: { label: 'Month45', payments: 0, lexisCare: 0 },
            month46: { label: 'Month46', payments: 0, lexisCare: 0 },
            month47: { label: 'Month47', payments: 0, lexisCare: 0 },
            month48: { label: 'Month48', payments: 0, lexisCare: 0 },
            month49: { label: 'Month49', payments: 0, lexisCare: 0 },
            month50: { label: 'Month50', payments: 0, lexisCare: 0 },
            month51: { label: 'Month51', payments: 0, lexisCare: 0 },
            month52: { label: 'Month52', payments: 0, lexisCare: 0 },
            month53: { label: 'Month53', payments: 0, lexisCare: 0 },
            month54: { label: 'Month54', payments: 0, lexisCare: 0 },
            month55: { label: 'Month55', payments: 0, lexisCare: 0 },
            month56: { label: 'Month56', payments: 0, lexisCare: 0 },
            month57: { label: 'Month57', payments: 0, lexisCare: 0 },
            month58: { label: 'Month58', payments: 0, lexisCare: 0 },
            month59: { label: 'Month59', payments: 0, lexisCare: 0 },
            month60: { label: 'Month60', payments: 0, lexisCare: 0 },

            repaymentTotal: { label: 'Total', payments: 0, lexisCare: 0 },
        }
    }
    const [repaymentCalc, setRepaymentCalc] = React.useState(defaultRepayment);

    const [mandatoryFields, setMandatoryFields] = React.useState({
        clientName: true,
        opportunityNumber: true,
        numOfUsers: true,
        country: true,
        objective: true,
        upsell: true,
        solutionSpecialist: true,
        currentSoftware: true,
        duration: true,
        specialConditions: true,
    })
    const [fillValueErrors, setFillValueErrors] = React.useState({
        clientName: false,
        // opportunityNumber: false,
        numOfUsers: false,
        country: false,
        objective: false,
        upsell: false,
        solutionSpecialist: false,
        currentSoftware: false,
        duration: false,
        specialConditions: false,
        affinityServerCPU: false,
    })

    const [affinityServerPopup, setAffinityServerPopup] = React.useState(false);
    const CloseAffinityServerPopup = () => {
        setAffinityServerPopup(false);
    }

    const saveProposalFunc = async () => {

        setFillValueErrors((prevValue) => ({
            clientName: false,
            numOfUsers: false,
            country: false,
            objective: false,
            upsell: false,
            solutionSpecialist: false,
            currentSoftware: false,
            duration: false,
            specialConditions: false,
            affinityServerCPU: false,
        }))

        if (clientProfile.clientName.length < 3) {
            const autocompleteInput = document.querySelector('.client-name-autocomplete input');
            setFillValueErrors((prevValue) => ({ ...prevValue, clientName: true }));
            autocompleteInput.focus();
            return;
        }
        // check clientNUmber
        // if (clientProfile.clientNUmber.length < 3) {
        //     const autocompleteInput = document.querySelector('.client-name-autocomplete input');
        //     setFillValueErrors((prevValue) => ({ ...prevValue, clientName: true }));
        //     autocompleteInput.focus();
        //     return;
        // }
        if (clientProfile.numOfUsers === '') {
            const users = document.querySelector('.num-of-users input');
            setFillValueErrors((prevValue) => ({ ...prevValue, numOfUsers: true }));
            users.focus();
            return;
        }
        if (clientProfile.country === '') {
            const country = document.querySelector('.country input');
            setFillValueErrors((prevValue) => ({ ...prevValue, country: true }));
            country.focus();
            return;
        }
        if (clientProfile.objective === '') {
            const objective = document.querySelector('.objective input');
            setFillValueErrors((prevValue) => ({ ...prevValue, objective: true }));
            objective.focus();
            return;
        }
        if (clientProfile.objective === 'Upsell') {
            if (clientProfile.upsell === '') {
                const upsell = document.querySelector('.upsell input');
                setFillValueErrors((prevValue) => ({ ...prevValue, upsell: true }));
                upsell.focus();
                return;
            }
        }

        if (clientProfile.solutionSpecialistId === '') {
            const specialist = document.querySelector('.sln-specialist input');
            setFillValueErrors((prevValue) => ({ ...prevValue, solutionSpecialist: true }));
            specialist.focus();
            return;
        }
        if (clientProfile.objective === 'New Business') {
            if (clientProfile.currentSoftware === '') {
                const software = document.querySelector('.software input');
                setFillValueErrors((prevValue) => ({ ...prevValue, currentSoftware: true }));
                software.focus();
                return;
            }
            if (clientProfile.duration === '') {
                const duration = document.querySelector('.duration input');
                setFillValueErrors((prevValue) => ({ ...prevValue, duration: true }));
                duration.focus();
                return;
            }
        }

        if (Info.specialConditions === '') {
            const spl = document.querySelector('.spl-conditions textarea');
            setFillValueErrors((prevValue) => ({ ...prevValue, specialConditions: true }));
            spl.focus();
            // console.log(spl)
            return;
        }
        if (clientProfile.objective === 'New Business') {
            if (miscellaneous.affinityServer.included === '') {
                setFillValueErrors((prevValue) => ({ ...prevValue, affinityServerCPU: true }));
                setAffinityServerPopup(true);
                return;
            }
        }

        // dont upload empty sales notes

        // console.log('save called');
        // const result = await saveProposalAPI({ ...clientProfile, ...Info });
        // console.log(result, 'save proposal result');

    }

    const resetProposal = () => {
        setClientProfile(defaultClientProfile);
        setInfo(defaultInfo);
        setAttendingCourses(defaultAttendingCourses);
        setDefaultServicesValues(defaultServices);
        setOptionalServices(defaultOptionalServices);
        setMiscellaneous(defaultMiscellaneous);
        setNotes(defaultNotes);
        setUpfrontCost(defaultUpfrontCost);
        setOngoingMnt(defaultOngoingMnt);
        setRepaymentCalc(defaultRepayment);
    }

    return (
        <>
            <CssBaseline />
            <Header />
            <Container maxWidth="xl">

                <InfoPopup open={affinityServerPopup} OnClose={CloseAffinityServerPopup}
                    title="Affinity Server CPU Field Required"
                    bodyText="Please Fill the Included Field of Affinity Server CPU from Miscellaneous table in Implementation Section"
                />

                <ClientInfo
                    clientProfile={clientProfile}
                    setClientProfile={setClientProfile}
                    Info={Info}
                    setInfo={setInfo}
                    mandatoryFields={mandatoryFields}
                    setMandatoryFields={setMandatoryFields}
                    fillValueErrors={fillValueErrors}
                    setFillValueErrors={setFillValueErrors}
                />

                <SubTabs
                    clientProfile={clientProfile}
                    Info={Info}
                    attendingCourses={attendingCourses}
                    setAttendingCourses={setAttendingCourses}
                    defaultServicesValues={defaultServicesValues}
                    setDefaultServicesValues={setDefaultServicesValues}
                    optionalServices={optionalServices}
                    setOptionalServices={setOptionalServices}
                    miscellaneous={miscellaneous}
                    setMiscellaneous={setMiscellaneous}
                    notes={notes}
                    setNotes={setNotes}
                    upfrontCost={upfrontCost}
                    setUpfrontCost={setUpfrontCost}
                    ongoingMnt={ongoingMnt}
                    setOngoingMnt={setOngoingMnt}
                    repaymentCalc={repaymentCalc}
                    setRepaymentCalc={setRepaymentCalc}
                />


                <Box sx={{
                    marginTop: '-20px',
                    marginLeft: { xs: '0', sm: '1.6rem' }
                }}>
                    <Button onClick={saveProposalFunc} variant="contained" color="primary" sx={{ m: 1 }}>
                        Save Proposal
                    </Button>
                    <Button onClick={resetProposal} variant="contained" color="primary" sx={{ m: 1 }}>
                        Reset Proposal
                    </Button>
                </Box>
            </Container>

        </>
    )
}