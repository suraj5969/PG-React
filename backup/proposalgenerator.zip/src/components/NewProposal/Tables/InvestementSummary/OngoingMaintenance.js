import React from 'react';
import { Table, TableContainer, TableHead, TableRow, TableCell, TableBody, Button, Box } from '@material-ui/core';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormControl from '@mui/material/FormControl';
import { tableCellClasses } from '@mui/material/TableCell';
import { styled } from '@mui/material/styles';

export default function OngoingMaintenance(props) {

    const { ongoingMnt, setOngoingMnt, setValue } = props;

    const { annualAffinity, annualOracleCare, annualAffinityMobile, annualClient,
        annualEmpower, annualSoftDocs, annualSettlement, subTotal, lessConfidential,
        totalMntExclGST, GSTPayable, totalMntAnnual, totalMntMonthly,
        totalAnnualCost, totalCostMonth, } = ongoingMnt;

    const StyledHeadCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: '#4db6ac',
            color: 'white',
            textAlign: 'center',
            padding: '8px',
        },
    }));

    function isStringInteger(value) {
        return /^[0-9]*$/.test(value);
    }

    const handelPercentDiscount = (e) => {
        if (isStringInteger(e.target.value) && Number(e.target.value) <= 100) {
            setOngoingMnt((prevValues) => ({
                ...prevValues,
                [e.target.name]: {
                    ...prevValues[e.target.name],
                    percentDiscount: e.target.value
                },
            }))
        }
    }


    return (
        <Box sx={{ maxWidth: '1000px' }}>
            <TableContainer>
                <Table className='subtable'>
                    <TableHead>
                        <TableRow >
                            <StyledHeadCell style={{ textAlign: 'left' }}>Ongoing Maintenance Fees (Lexis Care)</StyledHeadCell>
                            <StyledHeadCell> Cost </StyledHeadCell>
                            <StyledHeadCell> Percent Discount </StyledHeadCell>
                            <StyledHeadCell> Discount Item Cost</StyledHeadCell>
                            <StyledHeadCell> Discount Amount </StyledHeadCell>
                        </TableRow>
                    </TableHead>
                    <TableBody >

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {annualAffinity.label}
                            </TableCell>
                            <TableCell align="center">${annualAffinity.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="annualAffinity"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={annualAffinity.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${annualAffinity.discountItemcost}</TableCell>
                            <TableCell align="center">${annualAffinity.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {annualOracleCare.label}
                            </TableCell>
                            <TableCell align="center">${annualOracleCare.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="annualOracleCare"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={annualOracleCare.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${annualOracleCare.discountItemcost}</TableCell>
                            <TableCell align="center">${annualOracleCare.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {annualAffinityMobile.label}
                            </TableCell>
                            <TableCell align="center">${annualAffinityMobile.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="annualAffinityMobile"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={annualAffinityMobile.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${annualAffinityMobile.discountItemcost}</TableCell>
                            <TableCell align="center">${annualAffinityMobile.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {annualClient.label}
                            </TableCell>
                            <TableCell align="center">${annualClient.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="annualClient"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={annualClient.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${annualClient.discountItemcost}</TableCell>
                            <TableCell align="center">${annualClient.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {annualEmpower.label}
                            </TableCell>
                            <TableCell align="center">${annualEmpower.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="annualEmpower"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={annualEmpower.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${annualEmpower.discountItemcost}</TableCell>
                            <TableCell align="center">${annualEmpower.discountAmount}</TableCell>
                        </TableRow>


                        <TableRow >
                            <TableCell component="th" scope="row">
                                {annualSoftDocs.label}
                            </TableCell>
                            <TableCell align="center">${annualSoftDocs.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="annualSoftDocs"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={annualSoftDocs.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${annualSoftDocs.discountItemcost}</TableCell>
                            <TableCell align="center">${annualSoftDocs.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {annualSettlement.label}
                            </TableCell>
                            <TableCell align="center">${annualSettlement.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="annualSettlement"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={annualSettlement.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${annualSettlement.discountItemcost}</TableCell>
                            <TableCell align="center">${annualSettlement.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                <b> {subTotal.label} </b>
                            </TableCell>
                            <TableCell align="center">${subTotal.cost}</TableCell>
                            <TableCell align="center">
                                <FormControl variant="outlined">
                                    <OutlinedInput
                                        name="subTotal"
                                        inputProps={{ style: { textAlign: 'center' }, maxLength: 3 }}
                                        sx={{ height: '25px', maxWidth: '120px' }}
                                        value={subTotal.percentDiscount}
                                        onChange={handelPercentDiscount}
                                    />
                                </FormControl>
                            </TableCell>
                            <TableCell align="center">${subTotal.discountItemcost}</TableCell>
                            <TableCell align="center">${subTotal.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {lessConfidential.label}
                            </TableCell>
                            <TableCell align="center">${lessConfidential.cost}</TableCell>
                            <TableCell align="center">{lessConfidential.percentDiscount}</TableCell>
                            <TableCell align="center">{lessConfidential.discountItemcost}</TableCell>
                            <TableCell align="center">{lessConfidential.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {totalMntExclGST.label}
                            </TableCell>
                            <TableCell align="center">${totalMntExclGST.cost}</TableCell>
                            <TableCell align="center">{totalMntExclGST.percentDiscount}</TableCell>
                            <TableCell align="center">{totalMntExclGST.discountItemcost}</TableCell>
                            <TableCell align="center">{totalMntExclGST.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {GSTPayable.label}
                            </TableCell>
                            <TableCell align="center">${GSTPayable.cost}</TableCell>
                            <TableCell align="center">{GSTPayable.percentDiscount}</TableCell>
                            <TableCell align="center">{GSTPayable.discountItemcost}</TableCell>
                            <TableCell align="center">{GSTPayable.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {totalMntAnnual.label}
                            </TableCell>
                            <TableCell align="center">${totalMntAnnual.cost}</TableCell>
                            <TableCell align="center">{totalMntAnnual.percentDiscount}</TableCell>
                            <TableCell align="center">{totalMntAnnual.discountItemcost}</TableCell>
                            <TableCell align="center">{totalMntAnnual.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {totalMntMonthly.label}
                            </TableCell>
                            <TableCell align="center">${totalMntMonthly.cost}</TableCell>
                            <TableCell align="center">{totalMntMonthly.percentDiscount}</TableCell>
                            <TableCell align="center">{totalMntMonthly.discountItemcost}</TableCell>
                            <TableCell align="center">{totalMntMonthly.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {totalAnnualCost.label}
                            </TableCell>
                            <TableCell align="center">${totalAnnualCost.cost}</TableCell>
                            <TableCell align="center">{totalAnnualCost.percentDiscount}</TableCell>
                            <TableCell align="center">{totalAnnualCost.discountItemcost}</TableCell>
                            <TableCell align="center">{totalAnnualCost.discountAmount}</TableCell>
                        </TableRow>

                        <TableRow >
                            <TableCell component="th" scope="row">
                                {totalCostMonth.label}
                            </TableCell>
                            <TableCell align="center">${totalCostMonth.cost}</TableCell>
                            <TableCell align="center">{totalCostMonth.percentDiscount}</TableCell>
                            <TableCell align="center">{totalCostMonth.discountItemcost}</TableCell>
                            <TableCell align="center">{totalCostMonth.discountAmount}</TableCell>
                        </TableRow>

                    </TableBody>
                </Table>
            </TableContainer>
            <Box sx={{ marginTop: 20, marginLeft: 10 }}>
                <Button onClick={() => setValue(3)}
                    variant="contained" color="primary" >Next</Button>
            </Box>
        </Box>
    );
}