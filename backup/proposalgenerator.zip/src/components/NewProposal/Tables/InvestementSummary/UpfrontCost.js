import React from 'react';
import { Table, TableContainer, TableHead, TableRow, TableCell, TableBody, Button, Box } from '@material-ui/core';
import OutlinedInput from '@mui/material/OutlinedInput';
import Stack from '@mui/material/Stack';
import Typography from '@material-ui/core/Typography';
import FormControl from '@mui/material/FormControl';
import { tableCellClasses } from '@mui/material/TableCell';
import { styled } from '@mui/material/styles';

export default function UpfrontCosts(props) {

    const { upfrontCost, setUpfrontCost, setInvestmentTabValue } = props;

    const { softwareDiscount, serviceDiscount, lexisServerLicense, lexisUserLicense,
        oracleLicenses, clientPortal, affinityMobile, lexisSettleAdjuster, twoWayMicrosoft,
        empower, softDocs, ImplementServices, ImplementTraning, postImplementation,
        dataMigration, travelAllowance, scopingStudy, propertyPrecedent,
        subTotal, lessConfidential, totalInvesteExcl, GSTPayable, totalInvestePay,
        totalPerUser, } = upfrontCost;

    const StyledHeadCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: '#4db6ac',
            color: 'white',
            textAlign: 'center',
            padding: '8px',
        },
    }));

    const GreyTableRow = styled(TableRow)(({ theme }) => ({
        '&': {
            backgroundColor: '#bbb',
        },
    }));

    function isStringInteger(value) {
        return /^[0-9]*$/.test(value);
    }

    const handelSoftwareDiscount = (e) => {
        if (isStringInteger(e.target.value) && Number(e.target.value) <= 100) {
            setUpfrontCost((prevValues) => ({
                ...prevValues,
                softwareDiscount: e.target.value,
                lexisServerLicense: {
                    ...prevValues.lexisServerLicense,
                    percentDiscount: Number(e.target.value),
                },
                lexisUserLicense: {
                    ...prevValues.lexisUserLicense,
                    percentDiscount: Number(e.target.value),
                },
                oracleLicenses: {
                    ...prevValues.oracleLicenses,
                    percentDiscount: Number(e.target.value),
                },
                clientPortal: {
                    ...prevValues.clientPortal,
                    percentDiscount: Number(e.target.value),
                },
                affinityMobile: {
                    ...prevValues.affinityMobile,
                    percentDiscount: Number(e.target.value),
                },
                lexisSettleAdjuster: {
                    ...prevValues.lexisSettleAdjuster,
                    percentDiscount: Number(e.target.value),
                },
                twoWayMicrosoft: {
                    ...prevValues.twoWayMicrosoft,
                    percentDiscount: Number(e.target.value),
                },
                empower: {
                    ...prevValues.empower,
                    percentDiscount: Number(e.target.value),
                },
                softDocs: {
                    ...prevValues.softDocs,
                    percentDiscount: Number(e.target.value),
                },
            }))
        }
    }

    const handelServiceDiscount = (e) => {
        if (isStringInteger(e.target.value) && Number(e.target.value) <= 100) {
            setUpfrontCost((prevValues) => ({
                ...prevValues,
                serviceDiscount: e.target.value,
                ImplementServices: {
                    ...prevValues.ImplementServices,
                    percentDiscount: Number(e.target.value),
                },
                ImplementTraning: {
                    ...prevValues.ImplementTraning,
                    percentDiscount: Number(e.target.value),
                },
                postImplementation: {
                    ...prevValues.postImplementation,
                    percentDiscount: Number(e.target.value),
                },
                dataMigration: {
                    ...prevValues.dataMigration,
                    percentDiscount: Number(e.target.value),
                },
                scopingStudy: {
                    ...prevValues.scopingStudy,
                    percentDiscount: Number(e.target.value),
                },
                propertyPrecedent: {
                    ...prevValues.propertyPrecedent,
                    percentDiscount: Number(e.target.value),
                },
                subTotal: {
                    ...prevValues.subTotal,
                    percentDiscount: Number(e.target.value),
                },
            }))
        }
    }

    const handelPercentDiscount = (e) => {
        if (isStringInteger(e.target.value) && Number(e.target.value) <= 100) {
            setUpfrontCost((prevValues) => ({
                ...prevValues,
                [e.target.name]: {
                    ...prevValues[e.target.name],
                    percentDiscount: e.target.value
                },
            }))
        }
    }


    return (
        <Box sx={{ maxWidth: '1000px' }}>
            <Stack direction="row" spacing={2} sx={{ justifyContent: 'space-between', marginBottom: '1.3rem' }}>
                <Stack direction="row" spacing={1} sx={{ alignItems: 'center' }}>
                    <Typography variant="subtitle1">Discount for software </Typography>
                    <FormControl variant="outlined">
                        <OutlinedInput
                            inputProps={{ maxLength: 3 }}
                            sx={{ height: '35px' }}
                            value={softwareDiscount}
                            onChange={handelSoftwareDiscount}
                        />
                    </FormControl>
                </Stack>
                <Stack direction="row" spacing={1} sx={{ alignItems: 'center' }}>
                    <Typography variant="subtitle1">Discount for services </Typography>
                    <FormControl variant="outlined">
                        <OutlinedInput
                            inputProps={{ maxLength: 3 }}
                            sx={{ height: '35px' }}
                            value={serviceDiscount}
                            onChange={handelServiceDiscount}
                        />
                    </FormControl>
                </Stack>
            </Stack>

            <Box>
                <TableContainer>
                    <Table className='subtable'>
                        <TableHead>
                            <TableRow >
                                <StyledHeadCell style={{ textAlign: 'left' }}>Initial Investment Costs(Upfront Costs)</StyledHeadCell>
                                <StyledHeadCell> Cost </StyledHeadCell>
                                <StyledHeadCell> Percent Discount </StyledHeadCell>
                                <StyledHeadCell> Discount Item Cost</StyledHeadCell>
                                <StyledHeadCell> Discount Amount </StyledHeadCell>
                            </TableRow>
                        </TableHead>
                        <TableBody >

                            <GreyTableRow>
                                <TableCell><b>Software Licenses</b></TableCell>
                                <TableCell></TableCell>
                                <TableCell></TableCell>
                                <TableCell></TableCell>
                                <TableCell></TableCell>
                            </GreyTableRow>
                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {lexisServerLicense.label}
                                </TableCell>
                                <TableCell align="center">${lexisServerLicense.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="lexisServerLicense"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={lexisServerLicense.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${lexisServerLicense.discountItemcost}</TableCell>
                                <TableCell align="center">${lexisServerLicense.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {lexisUserLicense.label}
                                </TableCell>
                                <TableCell align="center">${lexisUserLicense.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="lexisUserLicense"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={lexisUserLicense.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${lexisUserLicense.discountItemcost}</TableCell>
                                <TableCell align="center">${lexisUserLicense.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {oracleLicenses.label}
                                </TableCell>
                                <TableCell align="center">${oracleLicenses.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="oracleLicenses"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={oracleLicenses.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${oracleLicenses.discountItemcost}</TableCell>
                                <TableCell align="center">${oracleLicenses.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {clientPortal.label}
                                </TableCell>
                                <TableCell align="center">${clientPortal.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="clientPortal"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={clientPortal.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${clientPortal.discountItemcost}</TableCell>
                                <TableCell align="center">${clientPortal.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {affinityMobile.label}
                                </TableCell>
                                <TableCell align="center">${affinityMobile.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="affinityMobile"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={affinityMobile.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${affinityMobile.discountItemcost}</TableCell>
                                <TableCell align="center">${affinityMobile.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {lexisSettleAdjuster.label}
                                </TableCell>
                                <TableCell align="center">${lexisSettleAdjuster.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="lexisSettleAdjuster"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={lexisSettleAdjuster.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${lexisSettleAdjuster.discountItemcost}</TableCell>
                                <TableCell align="center">${lexisSettleAdjuster.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {twoWayMicrosoft.label}
                                </TableCell>
                                <TableCell align="center">${twoWayMicrosoft.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="twoWayMicrosoft"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={twoWayMicrosoft.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${twoWayMicrosoft.discountItemcost}</TableCell>
                                <TableCell align="center">${twoWayMicrosoft.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {empower.label}
                                </TableCell>
                                <TableCell align="center">${empower.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="empower"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={empower.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${empower.discountItemcost}</TableCell>
                                <TableCell align="center">${empower.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {softDocs.label}
                                </TableCell>
                                <TableCell align="center">${softDocs.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="softDocs"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={softDocs.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${softDocs.discountItemcost}</TableCell>
                                <TableCell align="center">${softDocs.discountAmount}</TableCell>
                            </TableRow>


                            <GreyTableRow>
                                <TableCell><b>Professional Services</b></TableCell>
                                <TableCell></TableCell>
                                <TableCell></TableCell>
                                <TableCell></TableCell>
                                <TableCell></TableCell>
                            </GreyTableRow>
                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {ImplementServices.label}
                                </TableCell>
                                <TableCell align="center">${ImplementServices.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="ImplementServices"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={ImplementServices.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${ImplementServices.discountItemcost}</TableCell>
                                <TableCell align="center">${ImplementServices.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {ImplementTraning.label}
                                </TableCell>
                                <TableCell align="center">${ImplementTraning.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="ImplementTraning"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={ImplementTraning.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${ImplementTraning.discountItemcost}</TableCell>
                                <TableCell align="center">${ImplementTraning.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {postImplementation.label}
                                </TableCell>
                                <TableCell align="center">${postImplementation.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="postImplementation"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={postImplementation.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${postImplementation.discountItemcost}</TableCell>
                                <TableCell align="center">${postImplementation.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {dataMigration.label}
                                </TableCell>
                                <TableCell align="center">${dataMigration.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="dataMigration"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={dataMigration.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${dataMigration.discountItemcost}</TableCell>
                                <TableCell align="center">${dataMigration.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {travelAllowance.label}
                                </TableCell>
                                <TableCell align="center">${travelAllowance.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="travelAllowance"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={travelAllowance.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${travelAllowance.discountItemcost}</TableCell>
                                <TableCell align="center">${travelAllowance.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {scopingStudy.label}
                                </TableCell>
                                <TableCell align="center">${scopingStudy.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="scopingStudy"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={scopingStudy.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${scopingStudy.discountItemcost}</TableCell>
                                <TableCell align="center">${scopingStudy.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {propertyPrecedent.label}
                                </TableCell>
                                <TableCell align="center">${propertyPrecedent.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="propertyPrecedent"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={propertyPrecedent.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${propertyPrecedent.discountItemcost}</TableCell>
                                <TableCell align="center">${propertyPrecedent.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {subTotal.label}
                                </TableCell>
                                <TableCell align="center">${subTotal.cost}</TableCell>
                                <TableCell align="center">
                                    <FormControl variant="outlined">
                                        <OutlinedInput
                                            name="subTotal"
                                            inputProps={{ style: { textAlign: 'center', maxLength: 3 } }}
                                            sx={{ height: '25px', maxWidth: '120px' }}
                                            value={subTotal.percentDiscount}
                                            onChange={handelPercentDiscount}
                                        />
                                    </FormControl>
                                </TableCell>
                                <TableCell align="center">${subTotal.discountItemcost}</TableCell>
                                <TableCell align="center">${subTotal.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {lessConfidential.label}
                                </TableCell>
                                <TableCell align="center">${lessConfidential.cost}</TableCell>
                                <TableCell align="center">${lessConfidential.percentDiscount}</TableCell>
                                <TableCell align="center">${lessConfidential.discountItemcost}</TableCell>
                                <TableCell align="center">${lessConfidential.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {totalInvesteExcl.label}
                                </TableCell>
                                <TableCell align="center">${totalInvesteExcl.cost}</TableCell>
                                <TableCell align="center">${totalInvesteExcl.percentDiscount}</TableCell>
                                <TableCell align="center">${totalInvesteExcl.discountItemcost}</TableCell>
                                <TableCell align="center">${totalInvesteExcl.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {GSTPayable.label}
                                </TableCell>
                                <TableCell align="center">${GSTPayable.cost}</TableCell>
                                <TableCell align="center">${GSTPayable.percentDiscount}</TableCell>
                                <TableCell align="center">${GSTPayable.discountItemcost}</TableCell>
                                <TableCell align="center">${GSTPayable.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {totalInvestePay.label}
                                </TableCell>
                                <TableCell align="center">${totalInvestePay.cost}</TableCell>
                                <TableCell align="center">${totalInvestePay.percentDiscount}</TableCell>
                                <TableCell align="center">${totalInvestePay.discountItemcost}</TableCell>
                                <TableCell align="center">${totalInvestePay.discountAmount}</TableCell>
                            </TableRow>

                            <TableRow >
                                <TableCell component="th" scope="row">
                                    {totalPerUser.label}
                                </TableCell>
                                <TableCell align="center">${totalPerUser.cost}</TableCell>
                                <TableCell align="center">${totalPerUser.percentDiscount}</TableCell>
                                <TableCell align="center">${totalPerUser.discountItemcost}</TableCell>
                                <TableCell align="center">${totalPerUser.discountAmount}</TableCell>
                            </TableRow>

                        </TableBody>
                    </Table>
                </TableContainer>
                <Box sx={{ marginTop: 20, marginLeft: 10 }}>
                    <Button onClick={() => setInvestmentTabValue(1)}
                        variant="contained" color="primary" >Next</Button>
                </Box>
            </Box>
        </Box>
    );
}