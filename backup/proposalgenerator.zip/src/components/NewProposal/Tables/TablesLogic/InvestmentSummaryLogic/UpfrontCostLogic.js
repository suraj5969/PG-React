import React from 'react'

function UpfrontCostLogic(props) {

    const { clientProfile, upfrontCost, setUpfrontCost } = props;

    const { 
        // softwareDiscount, serviceDiscount,
         lexisServerLicense, lexisUserLicense,
        oracleLicenses, 
        // clientPortal, affinityMobile, lexisSettleAdjuster, twoWayMicrosoft,
        // empower, softDocs, ImplementServices, ImplementTraning, postImplementation,
        // dataMigration, travelAllowance, scopingStudy, propertyPrecedent,
        // subTotal, lessConfidential, totalInvesteExcl, GSTPayable, totalInvestePay,
        // totalPerUser,
     } = upfrontCost;



    //useEffect for column Cost for lexisServerLicense row 
    React.useEffect(() => {
        if (clientProfile.objective === 'Upsell') {
            setUpfrontCost((prevValues) => ({
                ...prevValues,
                lexisServerLicense: {
                    ...prevValues.lexisServerLicense,
                    cost: 0,
                },
            }))
        }
        else {
            if (clientProfile.objective === 'New Business') {
                // set price according to country
                setUpfrontCost((prevValues) => ({
                    ...prevValues,
                    lexisServerLicense: {
                        ...prevValues.lexisServerLicense,
                        cost: 10,
                    },
                }))
            }
        }

    }, [clientProfile.objective, clientProfile.country, setUpfrontCost])

    //useEffect for 2 column discountItemcost, discountAmount for lexisServerLicense row 
    React.useEffect(() => {
        setUpfrontCost((prevValues) => {
            const itemcost = Number(prevValues.lexisServerLicense.cost) -
                (Number(prevValues.lexisServerLicense.cost) * Number(prevValues.lexisServerLicense.percentDiscount)) / 100;
            const amount = (Number(prevValues.lexisServerLicense.cost) * Number(prevValues.lexisServerLicense.percentDiscount)) / 100;
            return {
                ...prevValues,
                lexisServerLicense: {
                    ...prevValues.lexisServerLicense,
                    discountItemcost: itemcost.toFixed(2),
                    discountAmount: amount.toFixed(2),
                },
            }
        })
    }, [lexisServerLicense.cost, lexisServerLicense.percentDiscount, setUpfrontCost])


    //useEffect for column label for lexisUserLicense row 
    React.useEffect(() => {
        setUpfrontCost((prevValues) => ({
            ...prevValues,
            lexisUserLicense: {
                ...prevValues.lexisUserLicense,
                label: `Lexis Affinity User licences for ${clientProfile.numOfUsers} users`,
            },
        }))
    }, [clientProfile.numOfUsers, setUpfrontCost])

    //useEffect for column Cost for lexisUserLicense row 
    React.useEffect(() => {
        // set value from DB
        setUpfrontCost((prevValues) => ({
            ...prevValues,
            lexisUserLicense: {
                ...prevValues.lexisUserLicense,
                cost: 10,
            },
        }))
    }, [clientProfile.numOfUsers, clientProfile.country, setUpfrontCost])

    //useEffect for 2 column discountItemcost, discountAmount for lexisUserLicense row 
    React.useEffect(() => {
        setUpfrontCost((prevValues) => {
            const itemcost = Number(prevValues.lexisUserLicense.cost) -
                (Number(prevValues.lexisUserLicense.cost) * Number(prevValues.lexisUserLicense.percentDiscount)) / 100;
            const amount = (Number(prevValues.lexisUserLicense.cost) * Number(prevValues.lexisUserLicense.percentDiscount)) / 100;
            return {
                ...prevValues,
                lexisUserLicense: {
                    ...prevValues.lexisUserLicense,
                    discountItemcost: itemcost.toFixed(2),
                    discountAmount: amount.toFixed(2),
                },
            }
        })
    }, [lexisUserLicense.cost, lexisUserLicense.percentDiscount, setUpfrontCost])

    //useEffect for 2 column discountItemcost, discountAmount for oracleLicenses row 
    React.useEffect(() => {
        setUpfrontCost((prevValues) => {
            const itemcost = Number(prevValues.oracleLicenses.cost) -
                (Number(prevValues.oracleLicenses.cost) * Number(prevValues.oracleLicenses.percentDiscount)) / 100;
            const amount = (Number(prevValues.oracleLicenses.cost) * Number(prevValues.oracleLicenses.percentDiscount)) / 100;
            return {
                ...prevValues,
                oracleLicenses: {
                    ...prevValues.oracleLicenses,
                    discountItemcost: itemcost.toFixed(2),
                    discountAmount: amount.toFixed(2),
                },
            }
        })
    }, [oracleLicenses.cost, oracleLicenses.percentDiscount, setUpfrontCost])


    return null;
}

export default UpfrontCostLogic;
