import React from 'react';
import UpfrontCostLogic from './UpfrontCostLogic';
import OngoingMaintenanceLogic from './OngoingMaintenanceLogic';

function InvestmentLogic(props) {
    return (
        <>
            <UpfrontCostLogic
                clientProfile={props.clientProfile}
                upfrontCost={props.upfrontCost}
                setUpfrontCost={props.setUpfrontCost}
            />

            <OngoingMaintenanceLogic
                clientProfile={props.clientProfile}
                ongoingMnt={props.ongoingMnt}
                setOngoingMnt={props.setOngoingMnt}
                upfrontCost={props.upfrontCost}
            />
        </>
    )
}

export default InvestmentLogic
