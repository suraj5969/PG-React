import React from 'react'

function MiscellaneousLogic(props) {

    const { clientProfile, miscellaneous, setMiscellaneous,
        setMiscellenousPopupsState } = props;

    const { affinityServer, scopingStudy, propertyPresidency } = miscellaneous;

    // additionalReturn included
    React.useEffect(() => {
        if (clientProfile.objective === 'Upsell') {
            setMiscellaneous((prevValue) => ({
                ...prevValue,
                additionalReturn: {
                    ...prevValue.additionalReturn,
                    included: 0
                }
            }))
        }
    }, [clientProfile.objective, setMiscellaneous])

    // propertyPresidency included
    React.useEffect(() => {
        if (clientProfile.country !== 'New Zealand') {
            setMiscellaneous((prevValue) => ({
                ...prevValue,
                propertyPresidency: {
                    ...prevValue.propertyPresidency,
                    included: 'No'
                }
            }))
        }
    }, [clientProfile.country, setMiscellaneous])

    // propertyPresidency price
    React.useEffect(() => {
        if (propertyPresidency.included !== 'Yes') {
            setMiscellaneous((prevValue) => ({
                ...prevValue,
                propertyPresidency: {
                    ...prevValue.propertyPresidency,
                    price: 0
                }
            }))
        }
    }, [propertyPresidency.included, setMiscellaneous])

    // scoping Stydy pop up values 
    React.useEffect(() => {
        if (scopingStudy.included === 'Yes') {
            setMiscellenousPopupsState((prevValue) => ({
                ...prevValue,
                scopingStudy: true
            }));
        }
        else {
            setMiscellaneous((prevValue) => ({
                ...prevValue,
                scopingStudy: {
                    ...prevValue.scopingStudy,
                    hours: 0,
                    price: 0
                }
            }))
        }
    }, [scopingStudy.included, setMiscellaneous, setMiscellenousPopupsState])


    // affinityServer CPU pop up values 
    React.useEffect(() => {
        if (affinityServer.included !== '') {
            setMiscellenousPopupsState((prevValue) => ({
                ...prevValue,
                affinityServer: true
            }));
        }
    }, [affinityServer.included, setMiscellenousPopupsState])


    return null;
}

export default MiscellaneousLogic;
