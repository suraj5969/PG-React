import React from 'react';
import { Table, TableContainer, TableHead, TableRow, TableCell, TableBody, Box } from '@material-ui/core';
import Stack from '@mui/material/Stack';
import FormControl from '@mui/material/FormControl';
import OutlinedInput from '@mui/material/OutlinedInput';
import Typography from '@mui/material/Typography';
import { tableCellClasses } from '@mui/material/TableCell';
import { styled } from '@mui/material/styles';

export default function RepaymentCalculator(props) {

    const { repaymentCalc, setRepaymentCalc } = props;

    const { totalsTable, mntTable, repayments } = repaymentCalc;

    const { software, services, sTotal, pricePerTool, priceTotal } = totalsTable;

    const { year1, year2, year3, year4, year5, mntTotal } = mntTable;

    const { initPayment, month1, month2, month3, month4, month5,
        month6, month7, month8, month9, month10,
        month11, month12, month13, month14, month15, month16, month17,
        month18, month19, month20, month21, month22, month23, month24,
        month25, month26, month27, month28, month29, month30, month31,
        month32, month33, month34, month35, month36, month37, month38,
        month39, month40, month41, month42, month43, month44, month45,
        month46, month47, month48, month49, month50, month51, month52,
        month53, month54, month55, month56, month57, month58, month59,
        month60, repaymentTotal } = repayments;


    const StyledHeadCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: '#4db6ac',
            color: 'white',
            textAlign: 'center',
            padding: '8px',
        },
    }));

    const GreyTableRow = styled(TableRow)(({ theme }) => ({
        '&': {
            backgroundColor: '#bbb',
        },
    }));

    const LeftBorderCell = styled(TableCell)(({ theme }) => ({
        '&': {
            borderLeft: '1px solid rgba(200,200,200,0.8)',
        },
    }));

    function isStringDecimal(value) {
        return /^[0-9.]*$/.test(value) && value.split('.').length < 3;
    }

    const [initPaymentError, setInitPaymentError] = React.useState(false);
    const handelInitPaymentChange = (event) => {
        if (isStringDecimal(event.target.value)) {
            if (Number(event.target.value) > Number(sTotal.cost)) {
                setInitPaymentError(true);
            }
            else {
                setInitPaymentError(false);
                setRepaymentCalc((prevValues) => ({
                    ...prevValues,
                    repayments: {
                        ...prevValues.repayments,
                        initPayment: {
                            ...prevValues.repayments.initPayment,
                            payments: event.target.value,
                        }
                    }
                }))
            }
        }

    }



    return (
        <Box sx={{ marginBottom: '1rem', }}>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={4}>
                <Box sx={{ width: '100%', maxWidth: '550px' }}>
                    <TableContainer>
                        <Table className='subtable'>
                            <TableHead>
                                <TableRow >
                                    <StyledHeadCell style={{ textAlign: 'left' }}></StyledHeadCell>
                                    <StyledHeadCell> Cost </StyledHeadCell>
                                    <StyledHeadCell> GCRM Entries </StyledHeadCell>
                                </TableRow>
                            </TableHead>
                            <TableBody >
                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {software.label}
                                    </TableCell>
                                    <TableCell align="center">${software.cost}</TableCell>
                                    <TableCell align="center">${software.gcrmEntries}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {services.label}
                                    </TableCell>
                                    <TableCell align="center">${services.cost}</TableCell>
                                    <TableCell align="center">${services.gcrmEntries}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {sTotal.label}
                                    </TableCell>
                                    <TableCell align="center">${sTotal.cost}</TableCell>
                                    <TableCell align="center">${sTotal.gcrmEntries}</TableCell>
                                </TableRow>


                                <GreyTableRow>
                                    <TableCell><b>Once-Off Costs</b></TableCell>
                                    <TableCell></TableCell>
                                    <TableCell></TableCell>
                                </GreyTableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {pricePerTool.label}
                                    </TableCell>
                                    <TableCell align="center">${pricePerTool.cost}</TableCell>
                                    <TableCell align="center">${pricePerTool.gcrmEntries}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {priceTotal.label}
                                    </TableCell>
                                    <TableCell align="center">${priceTotal.cost}</TableCell>
                                    <TableCell align="center">${priceTotal.gcrmEntries}</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>

                <Box sx={{ width: '100%', maxWidth: '550px' }}>
                    <TableContainer>
                        <Table className='subtable'>
                            <TableHead>
                                <TableRow >
                                    <StyledHeadCell style={{ textAlign: 'left' }}>Maintenance</StyledHeadCell>
                                    <StyledHeadCell> RRP </StyledHeadCell>
                                    <StyledHeadCell> Discounted </StyledHeadCell>
                                </TableRow>
                            </TableHead>
                            <TableBody >
                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {year1.label}
                                    </TableCell>
                                    <TableCell align="center">${year1.RRP}</TableCell>
                                    <TableCell align="center">${year1.discounted}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {year2.label}
                                    </TableCell>
                                    <TableCell align="center">${year2.RRP}</TableCell>
                                    <TableCell align="center">${year2.discounted}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {year3.label}
                                    </TableCell>
                                    <TableCell align="center">${year3.RRP}</TableCell>
                                    <TableCell align="center">${year3.discounted}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {year4.label}
                                    </TableCell>
                                    <TableCell align="center">${year4.RRP}</TableCell>
                                    <TableCell align="center">${year4.discounted}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {year5.label}
                                    </TableCell>
                                    <TableCell align="center">${year5.RRP}</TableCell>
                                    <TableCell align="center">${year5.discounted}</TableCell>
                                </TableRow>

                                <TableRow >
                                    <TableCell component="th" scope="row">
                                        {mntTotal.label}
                                    </TableCell>
                                    <TableCell align="center">${mntTotal.RRP}</TableCell>
                                    <TableCell align="center">${mntTotal.discounted}</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>
            </Stack>

            <Box sx={{ marginTop: '3rem' }}>
                <Stack style={{ flexDirection: 'row', alignItems: 'center', marginBottom: '1rem' }}>
                    <Box sx={{ flexGrow: 1 }} />
                    <Box sx={{ width: '100%', maxWidth: '700px' }}>
                        <TableContainer>
                            <Table className='subtable'>
                                <TableHead>
                                    <TableRow >
                                        <StyledHeadCell >Repayments</StyledHeadCell>
                                        <StyledHeadCell> Payments </StyledHeadCell>
                                        <StyledHeadCell> Lexis Care </StyledHeadCell>

                                        <StyledHeadCell sx={{ borderLeft: '1px solid rgba(200,200,200,0.8)' }}>Repayments</StyledHeadCell>
                                        <StyledHeadCell> Payments </StyledHeadCell>
                                        <StyledHeadCell> Lexis Care </StyledHeadCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody >
                                    <TableRow >
                                        <TableCell align="center" component="th" scope="row">
                                            {initPayment.label}
                                        </TableCell>
                                        <TableCell align="center">
                                            <FormControl variant="outlined">
                                                <OutlinedInput
                                                    inputProps={{ style: { textAlign: 'center' }, maxLength: 10 }}
                                                    sx={{ height: '25px', minWidth: '130px', maxWidth: '140px' }}
                                                    value={initPayment.payments}
                                                    onChange={handelInitPaymentChange}
                                                />
                                            </FormControl>
                                            {initPaymentError ? <Typography variant="subtitle2" style={{ color: 'red' }}> This field cannot be grater than {sTotal.cost} </Typography> : ''}
                                        </TableCell>
                                        <TableCell align="center">${initPayment.lexisCare}</TableCell>

                                        <LeftBorderCell align="center" component="th" scope="row">
                                            {repaymentTotal.label}
                                        </LeftBorderCell>
                                        <TableCell align="center">${repaymentTotal.payments}</TableCell>
                                        <TableCell align="center">${repaymentTotal.lexisCare}</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Box>
                    {/* <Typography > Initial Payment :</Typography>
                    <FormControl variant="outlined">
                        <OutlinedInput
                            inputProps={{ style: { textAlign: 'center' }, maxLength: 10 }}
                            sx={{ height: '35px', maxWidth: '180px' }}
                        // value={operationsCourse.accountsTraining}
                        // onChange={handelTraningChange}
                        />
                    </FormControl> */}
                </Stack>
                <TableContainer>
                    <Table className='subtable'>
                        <TableHead>
                            <TableRow >

                                <StyledHeadCell >Repayments</StyledHeadCell>
                                <StyledHeadCell> Payments </StyledHeadCell>
                                <StyledHeadCell> Lexis Care </StyledHeadCell>

                                <StyledHeadCell sx={{ borderLeft: '1px solid rgba(200,200,200,0.8)' }}>Repayments</StyledHeadCell>
                                <StyledHeadCell> Payments </StyledHeadCell>
                                <StyledHeadCell> Lexis Care </StyledHeadCell>

                                <StyledHeadCell sx={{ borderLeft: '1px solid rgba(200,200,200,0.8)' }}>Repayments</StyledHeadCell>
                                <StyledHeadCell> Payments </StyledHeadCell>
                                <StyledHeadCell> Lexis Care </StyledHeadCell>

                                <StyledHeadCell sx={{ borderLeft: '1px solid rgba(200,200,200,0.8)' }}>Repayments</StyledHeadCell>
                                <StyledHeadCell> Payments </StyledHeadCell>
                                <StyledHeadCell> Lexis Care </StyledHeadCell>

                                <StyledHeadCell sx={{ borderLeft: '1px solid rgba(200,200,200,0.8)' }}>Repayments</StyledHeadCell>
                                <StyledHeadCell> Payments </StyledHeadCell>
                                <StyledHeadCell> Lexis Care </StyledHeadCell>
                            </TableRow>
                        </TableHead>
                        <TableBody >
                            <TableRow >
                                <TableCell align="center">{month1.label}</TableCell>
                                <TableCell align="center">${month1.payments}</TableCell>
                                <TableCell align="center">${month1.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month13.label}</LeftBorderCell>
                                <TableCell align="center">${month13.payments}</TableCell>
                                <TableCell align="center">${month13.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month25.label}</LeftBorderCell>
                                <TableCell align="center">${month25.payments}</TableCell>
                                <TableCell align="center">${month25.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month37.label}</LeftBorderCell>
                                <TableCell align="center">${month37.payments}</TableCell>
                                <TableCell align="center">${month37.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month49.label}</LeftBorderCell>
                                <TableCell align="center">${month49.payments}</TableCell>
                                <TableCell align="center">${month49.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month2.label}</TableCell>
                                <TableCell align="center">${month2.payments}</TableCell>
                                <TableCell align="center">${month2.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month14.label}</LeftBorderCell>
                                <TableCell align="center">${month14.payments}</TableCell>
                                <TableCell align="center">${month14.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month26.label}</LeftBorderCell>
                                <TableCell align="center">${month26.payments}</TableCell>
                                <TableCell align="center">${month26.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month38.label}</LeftBorderCell>
                                <TableCell align="center">${month38.payments}</TableCell>
                                <TableCell align="center">${month38.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month50.label}</LeftBorderCell>
                                <TableCell align="center">${month50.payments}</TableCell>
                                <TableCell align="center">${month50.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month3.label}</TableCell>
                                <TableCell align="center">${month3.payments}</TableCell>
                                <TableCell align="center">${month3.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month15.label}</LeftBorderCell>
                                <TableCell align="center">${month15.payments}</TableCell>
                                <TableCell align="center">${month15.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month27.label}</LeftBorderCell>
                                <TableCell align="center">${month27.payments}</TableCell>
                                <TableCell align="center">${month27.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month39.label}</LeftBorderCell>
                                <TableCell align="center">${month39.payments}</TableCell>
                                <TableCell align="center">${month39.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month51.label}</LeftBorderCell>
                                <TableCell align="center">${month51.payments}</TableCell>
                                <TableCell align="center">${month51.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month4.label}</TableCell>
                                <TableCell align="center">${month4.payments}</TableCell>
                                <TableCell align="center">${month4.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month16.label}</LeftBorderCell>
                                <TableCell align="center">${month16.payments}</TableCell>
                                <TableCell align="center">${month16.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month28.label}</LeftBorderCell>
                                <TableCell align="center">${month28.payments}</TableCell>
                                <TableCell align="center">${month28.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month40.label}</LeftBorderCell>
                                <TableCell align="center">${month40.payments}</TableCell>
                                <TableCell align="center">${month40.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month52.label}</LeftBorderCell>
                                <TableCell align="center">${month52.payments}</TableCell>
                                <TableCell align="center">${month52.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month5.label}</TableCell>
                                <TableCell align="center">${month5.payments}</TableCell>
                                <TableCell align="center">${month5.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month17.label}</LeftBorderCell>
                                <TableCell align="center">${month17.payments}</TableCell>
                                <TableCell align="center">${month17.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month29.label}</LeftBorderCell>
                                <TableCell align="center">${month29.payments}</TableCell>
                                <TableCell align="center">${month29.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month41.label}</LeftBorderCell>
                                <TableCell align="center">${month41.payments}</TableCell>
                                <TableCell align="center">${month41.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month53.label}</LeftBorderCell>
                                <TableCell align="center">${month53.payments}</TableCell>
                                <TableCell align="center">${month53.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month6.label}</TableCell>
                                <TableCell align="center">${month6.payments}</TableCell>
                                <TableCell align="center">${month6.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month18.label}</LeftBorderCell>
                                <TableCell align="center">${month18.payments}</TableCell>
                                <TableCell align="center">${month18.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month30.label}</LeftBorderCell>
                                <TableCell align="center">${month30.payments}</TableCell>
                                <TableCell align="center">${month30.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month42.label}</LeftBorderCell>
                                <TableCell align="center">${month42.payments}</TableCell>
                                <TableCell align="center">${month42.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month54.label}</LeftBorderCell>
                                <TableCell align="center">${month54.payments}</TableCell>
                                <TableCell align="center">${month54.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month7.label}</TableCell>
                                <TableCell align="center">${month7.payments}</TableCell>
                                <TableCell align="center">${month7.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month19.label}</LeftBorderCell>
                                <TableCell align="center">${month19.payments}</TableCell>
                                <TableCell align="center">${month19.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month31.label}</LeftBorderCell>
                                <TableCell align="center">${month31.payments}</TableCell>
                                <TableCell align="center">${month31.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month43.label}</LeftBorderCell>
                                <TableCell align="center">${month43.payments}</TableCell>
                                <TableCell align="center">${month43.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month55.label}</LeftBorderCell>
                                <TableCell align="center">${month55.payments}</TableCell>
                                <TableCell align="center">${month55.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month8.label}</TableCell>
                                <TableCell align="center">${month8.payments}</TableCell>
                                <TableCell align="center">${month8.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month20.label}</LeftBorderCell>
                                <TableCell align="center">${month20.payments}</TableCell>
                                <TableCell align="center">${month20.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month32.label}</LeftBorderCell>
                                <TableCell align="center">${month32.payments}</TableCell>
                                <TableCell align="center">${month32.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month44.label}</LeftBorderCell>
                                <TableCell align="center">${month44.payments}</TableCell>
                                <TableCell align="center">${month44.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month56.label}</LeftBorderCell>
                                <TableCell align="center">${month56.payments}</TableCell>
                                <TableCell align="center">${month56.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month9.label}</TableCell>
                                <TableCell align="center">${month9.payments}</TableCell>
                                <TableCell align="center">${month9.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month21.label}</LeftBorderCell>
                                <TableCell align="center">${month21.payments}</TableCell>
                                <TableCell align="center">${month21.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month33.label}</LeftBorderCell>
                                <TableCell align="center">${month33.payments}</TableCell>
                                <TableCell align="center">${month33.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month45.label}</LeftBorderCell>
                                <TableCell align="center">${month45.payments}</TableCell>
                                <TableCell align="center">${month45.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month57.label}</LeftBorderCell>
                                <TableCell align="center">${month57.payments}</TableCell>
                                <TableCell align="center">${month57.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month10.label}</TableCell>
                                <TableCell align="center">${month10.payments}</TableCell>
                                <TableCell align="center">${month10.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month22.label}</LeftBorderCell>
                                <TableCell align="center">${month22.payments}</TableCell>
                                <TableCell align="center">${month22.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month34.label}</LeftBorderCell>
                                <TableCell align="center">${month34.payments}</TableCell>
                                <TableCell align="center">${month34.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month46.label}</LeftBorderCell>
                                <TableCell align="center">${month46.payments}</TableCell>
                                <TableCell align="center">${month46.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month58.label}</LeftBorderCell>
                                <TableCell align="center">${month58.payments}</TableCell>
                                <TableCell align="center">${month58.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month11.label}</TableCell>
                                <TableCell align="center">${month1.payments}</TableCell>
                                <TableCell align="center">${month1.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month23.label}</LeftBorderCell>
                                <TableCell align="center">${month23.payments}</TableCell>
                                <TableCell align="center">${month23.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month35.label}</LeftBorderCell>
                                <TableCell align="center">${month35.payments}</TableCell>
                                <TableCell align="center">${month35.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month47.label}</LeftBorderCell>
                                <TableCell align="center">${month47.payments}</TableCell>
                                <TableCell align="center">${month47.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month59.label}</LeftBorderCell>
                                <TableCell align="center">${month59.payments}</TableCell>
                                <TableCell align="center">${month59.lexisCare}</TableCell>
                            </TableRow>
                            <TableRow >
                                <TableCell align="center">{month12.label}</TableCell>
                                <TableCell align="center">${month12.payments}</TableCell>
                                <TableCell align="center">${month12.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month24.label}</LeftBorderCell>
                                <TableCell align="center">${month24.payments}</TableCell>
                                <TableCell align="center">${month24.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month36.label}</LeftBorderCell>
                                <TableCell align="center">${month36.payments}</TableCell>
                                <TableCell align="center">${month36.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month48.label}</LeftBorderCell>
                                <TableCell align="center">${month48.payments}</TableCell>
                                <TableCell align="center">${month48.lexisCare}</TableCell>

                                <LeftBorderCell align="center">{month60.label}</LeftBorderCell>
                                <TableCell align="center">${month60.payments}</TableCell>
                                <TableCell align="center">${month60.lexisCare}</TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </TableContainer>
                {/* <Stack gap={1} style={{ flexDirection: 'row', alignItems: 'center', marginTop: '1rem' }}>
                    <Box sx={{ flexGrow: 1 }} />
                    <Typography variant="h6"> Total :</Typography>
                    <Typography style={{ marginRight: '1rem' }} > $0.00</Typography>
                </Stack> */}
            </Box>
        </Box>
    );
}