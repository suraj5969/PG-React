import React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import PropTypes from 'prop-types';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import FormControlLabel from '@mui/material/FormControlLabel';
import Button from '@mui/material/Button';
import getAllDataMigrationOptions from '../../../apis/getAllDataMigrationOptionsAPI'

const lodashFilter = require('lodash.filter');


export default function DataMigrationPopup(props) {
    const { onClose, open, clientProfile, ...other } = props;
    const [migrationId, setMigrationId] = React.useState('');

    const [allOptions, setAllOptions] = React.useState([]);
    const [currentOpts, setCurrentOpts] = React.useState([]);

    React.useEffect(() => {
        if (!open) {
            setMigrationId('');
        }
    }, [open]);

    React.useEffect(() => {
        const fetchData = async () => {
            const result = await getAllDataMigrationOptions();
            if (result.status !== 200) {
                console.log('data migration api no working');
            }
            else {
                if (result.data.length > 0) {
                    setAllOptions(result.data);
                    // console.log(result.data)
                }
            }
        }
        fetchData();
    }, [setAllOptions])

    React.useEffect(() => {
        if (clientProfile.country !== '' && allOptions.length > 0) {
            const options = lodashFilter(allOptions, { 'country_name': clientProfile.country });
            setCurrentOpts(options);
        }
        else {
            setCurrentOpts(allOptions);
        }

    }, [clientProfile.country, allOptions])


    const handleCancel = () => {
        onClose();
        
    };

    const handleOk = () => {
        // onClose(value);
        const value = lodashFilter(currentOpts, { 'migration_id': migrationId });
        // console.log(value);
        if(value.length > 0) {
            onClose(value[0]);
        }
        else {
            onClose();
        }
    };

    const handleChange = (event) => {
        setMigrationId(event.target.value);
    };

    return (
        <Dialog
            sx={{ '& .MuiDialog-paper': { width: '80%', height: '80vh', maxHeight: 500 } }}
            maxWidth="sm"
            open={open}
            {...other}
        >
            <DialogTitle>Data Migration Required?</DialogTitle>
            <DialogContent dividers>
                <RadioGroup
                    value={migrationId}
                    onChange={handleChange}
                >
                    {currentOpts.map((option) => (
                        <FormControlLabel
                            sx={{ my: 0.6 }}
                            value={option.migration_id}
                            key={option.migration_id}
                            control={<Radio />}
                            label={option.migration_name}
                        />
                    ))}
                </RadioGroup>
            </DialogContent>
            <DialogActions>
                <Button autoFocus onClick={handleCancel}>
                    Cancel
                </Button>
                <Button onClick={handleOk}>Ok</Button>
            </DialogActions>
        </Dialog>
    );
}

DataMigrationPopup.propTypes = {
    onClose: PropTypes.func.isRequired,
    open: PropTypes.bool.isRequired,
};
