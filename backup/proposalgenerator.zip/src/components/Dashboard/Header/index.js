import React from 'react';
import { styled, alpha } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import MenuItem from '@mui/material/MenuItem';
import Menu from '@mui/material/Menu';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Avatar from '@mui/material/Avatar';
import Select from '@mui/material/Select';
import Grid from '@mui/material/Grid';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import SwitchAccountRoundedIcon from '@mui/icons-material/SwitchAccountRounded';
import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';
import Logout from '@mui/icons-material/Logout';
import { teal } from '@mui/material/colors';
import { useStyles } from './styles';
import { useHistory, Link } from 'react-router-dom';
import './Header.css'



const StyledMenu = styled((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    {...props}
  />
))(({ theme }) => ({
  '& .MuiPaper-root': {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === 'light' ? 'rgb(55, 65, 81)' : theme.palette.grey[500],
    boxShadow:
      'rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px',
    '& .MuiMenu-list': {
      padding: '4px 0',
    },
    '& .MuiMenuItem-root': {
      '& .MuiSvgIcon-root': {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      '&:active': {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity,
        ),
      },
    },
  },
}));

export default function Header(props) {

    const {setFilterOptions} = props;

  const history = useHistory();

  const styles = useStyles();

  const approvalStatusEntries = ['All', 'Approved', 'Not Submitted for approvel', 'Pending for Ops Team Approval', 'Pending for Commercial Lead Approval', 'Proposal without GCRM Client', 'Rejected'];
  const [approvalStatus, setApprovalStatus] = React.useState(approvalStatusEntries[0]);
  const handleApprovalStatusChange = (event) => {
    setApprovalStatus(event.target.value);
  };

  const nextApproverEntries = ['All', 'Bejay Molino', 'David howlett', 'Rahul Test', 'Rutuja Lohokare']
  const [nextApprover, setnextApprover] = React.useState(nextApproverEntries[0]);
  const handleNextApproverChange = (event) => {
    setnextApprover(event.target.value);
  };

  const solutionSpecialistEntries = ['All', 'Adrian Giacominato', 'Rahul Nagare', 'Divina Pedroso', 'Romesh Suvarna']
  const [solutionSpecialist, setSolutionSpecialist] = React.useState(solutionSpecialistEntries[0]);
  const handleSolutionSpecialistChange = (event) => {
    setSolutionSpecialist(event.target.value);
  };

  const lifecycleEntries = ['All', 'Active only', 'Archived only']
  const [lifecycle, setLifecycle] = React.useState(lifecycleEntries[0]);
  const handleLifecycleChange = (event) => {
    setLifecycle(event.target.value);
  };

  React.useEffect(() => {
    setFilterOptions({
      approvalStatus: approvalStatus,
      nextApprover: nextApprover,
      solutionSpecialist: solutionSpecialist,
      lifecycle: lifecycle
    })
  }, [approvalStatus, nextApprover, solutionSpecialist, lifecycle, setFilterOptions])

  // const history = useHistory();

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const logOut = () => {
    handleClose();
    sessionStorage.clear();
    // history.push("/auth/login");
  }

  return (
    <Box sx={{ flexGrow: 1, maxWidth: '1500px', margin:{sm:'0 auto', xl:'20px auto 0 auto'} }} >
      <AppBar position="static" style={{ background: 'white', boxShadow: 'none' }} sx={{ paddingBottom: { xs: '0.5rem', md: 0 } }}>
        <Toolbar>
          <Grid container spacing={2} alignItems="center">
            <Grid item xl={1} md={1.8} sm={4} sx={{ p: 0 }}>
              <Link to="/" >
              <img src="/lexisnexis.png" alt="logo" style={{ width: '100%', maxWidth: '160px', paddingLeft: '0' }} />
              </Link>
            </Grid>
            <Grid item container spacing={2} xl={2.1} md={2.5} sm={5} sx={{ marginLeft: { xs: 0 }, marginTop: { sm: 0, md: 1 } }}>
              <Button variant="contained" className="header-button" title='create new proposal' onClick={()=> history.push('/new-proposal')}>New Proposal</Button>
              {/* <Button variant="contained" className="header-button" title='export records to excel'>Export</Button> */}
            </Grid>

            <Grid item container xl={7.2} md={7} sm={11.5} xs={12} spacing={2} style={{ display: 'flex', justifyContent: 'around' }} wrap="wrap" >
              <Grid item xl={2.5} md={3.1} sm={4} xs={12} >
                <FormControl fullWidth>
                  <InputLabel id="approval-status" style={{ color: 'black' }}>Approval Status</InputLabel>
                  <Select
                    labelId="approval-status"
                    id="approval-status-select"
                    value={approvalStatus}
                    label="Approval Status"
                    onChange={handleApprovalStatusChange}
                  >
                    {

                      approvalStatusEntries.map((item) => (
                        <MenuItem value={item} key={item}>{item}</MenuItem>
                      ))
                    }
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xl={2} md={2.7} sm={3.8} xs={12}>
                <FormControl fullWidth>
                  <InputLabel id="next-approver" style={{ color: 'black' }}>Next Approver</InputLabel>
                  <Select
                    labelId="next-approver"
                    id="next-approver-select"
                    value={nextApprover}
                    label="Next Approver"
                    onChange={handleNextApproverChange}
                  >
                    {

                      nextApproverEntries.map((item) => (
                        <MenuItem value={item} key={item}>{item}</MenuItem>
                      ))
                    }
                  </Select>
                </FormControl>
              </Grid>


              <Grid item xl={2} md={2.7} sm={3.8} xs={12}>
                <FormControl fullWidth>
                  <InputLabel id="solution-specialist" style={{ color: 'black' }}>Solution Specialist</InputLabel>
                  <Select
                    labelId="solution-specialist"
                    id="solution-specialist-select"
                    value={solutionSpecialist}
                    label="Solution Specialist"
                    onChange={handleSolutionSpecialistChange}
                  >
                    {

                      solutionSpecialistEntries.map((item) => (
                        <MenuItem value={item} key={item}>{item}</MenuItem>
                      ))
                    }
                  </Select>
                </FormControl>
              </Grid>


              <Grid item xl={1.8} md={2.5} sm={3.5} xs={12}>
                <FormControl fullWidth>
                  <InputLabel id="lifecycle" style={{ color: 'black' }}>Lifecycle</InputLabel>
                  <Select
                    labelId="lifecycle"
                    id="lifecycle-select"
                    value={lifecycle}
                    label="lifecycle"
                    onChange={handleLifecycleChange}
                  >
                    {

                      lifecycleEntries.map((item) => (
                        <MenuItem value={item} key={item}>{item}</MenuItem>
                      ))
                    }
                  </Select>
                </FormControl>
              </Grid>
            </Grid>

          </Grid>

          <Box className={styles.profile}>
            <Avatar sx={{ bgcolor: teal[900], width: 35, height: 35 }}>R</Avatar>
            <Button
              id="user-customized-button"
              className={styles.userMenu}
              aria-controls="user-customized-menu"
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
              variant="text"
              disableElevation
              onClick={handleClick}
              endIcon={<KeyboardArrowDownIcon />}
            >USER</Button>
            <StyledMenu
              id="user-menu"
              MenuListProps={{
                'aria-labelledby': 'user-menu-button',
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
            >
              <MenuItem onClick={handleClose}>
                <AccountCircleRoundedIcon />
                Profile
              </MenuItem>
              <MenuItem onClick={handleClose}>
                <SwitchAccountRoundedIcon />
                Switch to User
              </MenuItem>
              <MenuItem onClick={logOut}>
                <Logout />
                Logout
              </MenuItem>
            </StyledMenu>
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
