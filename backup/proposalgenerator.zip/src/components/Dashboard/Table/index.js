import React from "react";
import MaterialTable from "material-table";
import Header from "../Header";

// Import Material Icons
import { forwardRef } from 'react';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import './Table.css'



const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />)
};


const data = [
  {
    proposalNumber: "LNPROP576",
    clientName: "CNM Legal Pty Ltd",
    clientNumber: "422QKRB45",
    opportunityNumber: "1-5AZPQS5",
    numberOfUsers: 6,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP573",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP572",
    clientName: "JHK Legal",
    clientNumber: "42523HCS3",
    opportunityNumber: "1-5EFADM6",
    numberOfUsers: 52,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP570",
    clientName: "R4.0 Test Internal Account",
    clientNumber: "1000UETUH",
    opportunityNumber: "1-ZVP8IY",
    numberOfUsers: 10,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Tejesh Walmiki",
  },
  {
    proposalNumber: "LNPROP569",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 12,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP568",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP566",
    clientName: "John McKenzie",
    clientNumber: "424Y6HLDT",
    opportunityNumber: "1-325WGFG",
    numberOfUsers: 42,
    approvalStatus: "Pending for Ops Team Approval",
    nextApprover: "	Bejay Molino",
    solutionSpecialist: "Ravindra Varpe",
  },
  {
    proposalNumber: "LNPROP563",
    clientName: "Fazzini Lawyers & Consultants",
    clientNumber: "425424KVS",
    opportunityNumber: "1-5D8J65",
    numberOfUsers: 8,
    approvalStatus: "Rejected",
    nextApprover: "",
    solutionSpecialist: "Malcolm Mcnamara",
  },
  {
    proposalNumber: "LNPROP576",
    clientName: "CNM Legal Pty Ltd",
    clientNumber: "422QKRB45",
    opportunityNumber: "1-5AZPQS5",
    numberOfUsers: 6,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP573",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP572",
    clientName: "JHK Legal",
    clientNumber: "42523HCS3",
    opportunityNumber: "1-5EFADM6",
    numberOfUsers: 52,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP570",
    clientName: "R4.0 Test Internal Account",
    clientNumber: "1000UETUH",
    opportunityNumber: "1-ZVP8IY",
    numberOfUsers: 10,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Tejesh Walmiki",
  },
  {
    proposalNumber: "LNPROP569",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 12,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP568",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP566",
    clientName: "John McKenzie",
    clientNumber: "424Y6HLDT",
    opportunityNumber: "1-325WGFG",
    numberOfUsers: 42,
    approvalStatus: "Pending for Ops Team Approval",
    nextApprover: "	Bejay Molino",
    solutionSpecialist: "Ravindra Varpe",
  },
  {
    proposalNumber: "LNPROP563",
    clientName: "Fazzini Lawyers & Consultants",
    clientNumber: "425424KVS",
    opportunityNumber: "1-5D8J65",
    numberOfUsers: 8,
    approvalStatus: "Rejected",
    nextApprover: "",
    solutionSpecialist: "Malcolm Mcnamara",
  },

  {
    proposalNumber: "LNPROP576",
    clientName: "CNM Legal Pty Ltd",
    clientNumber: "422QKRB45",
    opportunityNumber: "1-5AZPQS5",
    numberOfUsers: 6,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP573",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP572",
    clientName: "JHK Legal",
    clientNumber: "42523HCS3",
    opportunityNumber: "1-5EFADM6",
    numberOfUsers: 52,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP570",
    clientName: "R4.0 Test Internal Account",
    clientNumber: "1000UETUH",
    opportunityNumber: "1-ZVP8IY",
    numberOfUsers: 10,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Tejesh Walmiki",
  },
  {
    proposalNumber: "LNPROP569",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 12,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP568",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP566",
    clientName: "John McKenzie",
    clientNumber: "424Y6HLDT",
    opportunityNumber: "1-325WGFG",
    numberOfUsers: 42,
    approvalStatus: "Pending for Ops Team Approval",
    nextApprover: "	Bejay Molino",
    solutionSpecialist: "Ravindra Varpe",
  },
  {
    proposalNumber: "LNPROP563",
    clientName: "Fazzini Lawyers & Consultants",
    clientNumber: "425424KVS",
    opportunityNumber: "1-5D8J65",
    numberOfUsers: 8,
    approvalStatus: "Rejected",
    nextApprover: "",
    solutionSpecialist: "Malcolm Mcnamara",
  },
  {
    proposalNumber: "LNPROP576",
    clientName: "CNM Legal Pty Ltd",
    clientNumber: "422QKRB45",
    opportunityNumber: "1-5AZPQS5",
    numberOfUsers: 6,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP573",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP572",
    clientName: "JHK Legal",
    clientNumber: "42523HCS3",
    opportunityNumber: "1-5EFADM6",
    numberOfUsers: 52,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP570",
    clientName: "R4.0 Test Internal Account",
    clientNumber: "1000UETUH",
    opportunityNumber: "1-ZVP8IY",
    numberOfUsers: 10,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Tejesh Walmiki",
  },
  {
    proposalNumber: "LNPROP569",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 12,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP568",
    clientName: "Ian Upjohn",
    clientNumber: "422MJX3H6",
    opportunityNumber: "1-325UNGT",
    numberOfUsers: 45,
    approvalStatus: "Approved",
    nextApprover: "",
    solutionSpecialist: "Rahul Nagare",
  },
  {
    proposalNumber: "LNPROP566",
    clientName: "John McKenzie",
    clientNumber: "424Y6HLDT",
    opportunityNumber: "1-325WGFG",
    numberOfUsers: 42,
    approvalStatus: "Pending for Ops Team Approval",
    nextApprover: "	Bejay Molino",
    solutionSpecialist: "Ravindra Varpe",
  },
  {
    proposalNumber: "LNPROP563",
    clientName: "Fazzini Lawyers & Consultants",
    clientNumber: "425424KVS",
    opportunityNumber: "1-5D8J65",
    numberOfUsers: 8,
    approvalStatus: "Rejected",
    nextApprover: "",
    solutionSpecialist: "Malcolm Mcnamara",
  },

];



export default function Table() {

  const [tableData, setTableData] = React.useState(data);

  const [filterOptions, setFilterOptions] = React.useState(
    {
      approvalStatus: 'All',
      nextApprover: 'All',
      solutionSpecialist: 'All',
      lifecycle: 'All'
    });


  React.useEffect(() => {

    let count = 0;
    count = filterOptions.approvalStatus === 'All' ? count : ++count;
    count = filterOptions.nextApprover === 'All' ? count : ++count;
    count = filterOptions.solutionSpecialist === 'All' ? count : ++count;
    count = filterOptions.lifecycle === 'All' ? count : ++count;

    // let tempData = tableData;
    // if (count <= 1) {
    //   tempData = data;
    // }

    if (count > 0) {

      // console.log('useeffect called')

      let FilteredData = data.filter(row => {

        if ((filterOptions.approvalStatus !== 'All') && (filterOptions.approvalStatus.trim().toLowerCase() !== row.approvalStatus.trim().toLowerCase())) {
          return false;
        }

        if ((filterOptions.nextApprover !== 'All') && (filterOptions.nextApprover.trim().toLowerCase() !== row.nextApprover.trim().toLowerCase())) {
          return false;
        }

        if ((filterOptions.solutionSpecialist !== 'All') && (filterOptions.solutionSpecialist.trim().toLowerCase() !== row.solutionSpecialist.trim().toLowerCase())) {
          return false;
        }

        // if ((filterOptions.lifecycle !== 'All') && (filterOptions.lifecycle.trim().toLowerCase() !== row.lifecycle.trim().toLowerCase())) {
        //   return false;
        // }

        return true;
      })

      setTableData(FilteredData);
    }
    else {
      setTableData(data);
    }


    // if (count === 0) {
    //   setTableData(data);
    // }
    // else {
    //   setTableData(FilteredData);
    // }

  }, [filterOptions])



  // const FilterData = (filterValues) => {
  //   let FilteredData = tableData.filter(row => row.approvalStatus === 'Rejected');
  //   setTableData(FilteredData);
  // }

  // const [numberOfRows, setnumberOfRows] = React.useState(10);
  // const handleRowsEntriesChange = (event) => {
  //   setnumberOfRows(event.target.value);
  // };

  // const tableRef = React.useRef(null);

  // React.useEffect(() => {
  //       tableRef.current.dataManager.changePageSize(numberOfRows);
  //  }, [numberOfRows]);



  const firstTableCellStyle = { borderRight: '1px solid #e5e5e5', borderLeft: '1px solid #e5e5e5' };
  const tableCellStyle = { borderRight: '1px solid #e5e5e5' };

  let columns = [
    { title: "Proposal Number", field: "proposalNumber", cellStyle: firstTableCellStyle },
    { title: "Client Name", field: "clientName", cellStyle: tableCellStyle },
    { title: "Client Number", field: "clientNumber", cellStyle: tableCellStyle },
    { title: "Opportunity Number", field: "opportunityNumber", cellStyle: tableCellStyle },
    { title: "Number of Users", field: "numberOfUsers", type: 'numeric', align: 'left', cellStyle: tableCellStyle },
    { title: "Approval Status", field: "approvalStatus", cellStyle: tableCellStyle },
    { title: "Next Approver", field: "nextApprover", cellStyle: tableCellStyle },
    { title: "Solution Specialist", field: "solutionSpecialist", cellStyle: tableCellStyle },
  ];

  // const handleApprovalStatusChange = () => alert('clicked'); 
  return (
    <>
      <Header setFilterOptions={setFilterOptions} />
      <div style={{ Width: "100%", maxWidth: '1500px', margin: '0 auto' }}>
        <MaterialTable
          icons={tableIcons}
          // components={{
          //   Toolbar: props => {
          //     let _props = { ...props, toolbarButtonAlignment: "left" }
          //     return (
          //       <MTableToolbar  {..._props} />
          //     )
          //   }
          // }}
          localization={{
            header: {
              actions: 'Operations',
            },
            body: {
              emptyDataSourceMessage: 'No records to display',
              filterRow: {
                filterTooltip: 'Filter'
              }
            }
          }}
          actions={[
            // {
            //   icon: () => <Typography variant="h6" sx={{p:0}}>Show</Typography>,
            //   isFreeAction: true,
            //   disabled:true
            // },
            // {
            //   icon: () => {
            //     return <FormControl sx={{p:0}}>
            //       <Select
            //         // labelId="approval-status"
            //         id="approval-status-select"
            //         value={numberOfRows}
            //         label="Approval Status"
            //         onChange={handleRowsEntriesChange}
            //       >
            //         <MenuItem value={10}>10</MenuItem>
            //         <MenuItem value={12}>12</MenuItem>
            //         <MenuItem value={15}>15</MenuItem>
            //       </Select>
            //     </FormControl>
            //   },
            //   // tooltip: 'Filter',
            //   // disabled:true,
            //   // onClick: (event, rowData) =>  null,
            //   isFreeAction: true
            // },
            // {
            //   icon: () => <Typography variant="h6" sx={{p:0}}>entires</Typography>,
            //   isFreeAction: true,
            //   disabled:true
            // },

            {
              icon: () => <VisibilityIcon />,
              tooltip: 'View proposal',
              onClick: (event, rowData) => alert("You saved " + rowData.name)
            },
            (rowData) => {
              return {

                icon: () => <EditIcon />,
                disabled: rowData.approvalStatus === ('Approved' || 'approved'),
                tooltip: 'Edit proposal',
                onClick: (event, rowData) => alert("You saved " + rowData.name)
              }
            },
            {
              icon: () => <ArchiveOutlinedIcon />,
              tooltip: 'Archive Proposal',
              onClick: (event, rowData) => alert("You saved " + rowData.name)
            }
          ]}

          columns={columns}
          data={tableData}
          options={{
            exportButton: true,
            exportAllData: true,
            exportFileName: "Proposals",

            headerStyle: {
              // position: 'sticky',
              // top : '0',
              backgroundColor: '#008080',
              color: '#FFF',
              fontSize: '1.1rem',
              borderRight: '1px solid #e5e5e5'
            },
            // maxBodyHeight: '95vh',
            draggable: false,
            disableHorizontalScroll: true,
            // paging:true,
            showTitle: false,
            // filtering: true,
            pageSize: 10,       // make initial page size
            emptyRowsWhenPaging: false,   // To avoid of having empty rows
            pageSizeOptions: [10, 25, 50],    // rows selection options
          }}
        />
      </div>
    </>
  );
}