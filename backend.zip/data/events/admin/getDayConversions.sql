/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [DAY_ID]
    ,[DAY_NAME]
    ,[NO_OF_DAYS]
FROM [dbo].[Day_Conversion]