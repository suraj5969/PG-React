
UPDATE [dbo].[oracle_wording]
    SET [wordings] = @wordings
        ,[value] = @value
WHERE [id]=@id