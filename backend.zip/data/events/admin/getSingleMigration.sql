/****single migration data****/
SELECT [migration_id]
      ,[migration_name]
      ,[more_than_ten_cost]
      ,[dm_hours]
      ,[account_consult_hrs]
      ,[australia]
      ,[new_zealand]
      ,[date_updated]
      ,[comments]
  FROM [dbo].[admin_data_migration_options]
where [migration_id]=@migration_id