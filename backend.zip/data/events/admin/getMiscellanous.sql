/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [id]
    ,[name]
    ,[value]
FROM [dbo].[Admin_misc]