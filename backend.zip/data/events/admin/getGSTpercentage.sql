
SELECT [id]
    ,[country_name]
    ,[gst_percentage]
FROM [dbo].[admin_gst_percentage]