
SELECT [id]
    ,[soft_name]
    ,[version]
FROM [dbo].[soft_client_on]