SELECT [service_id]
        ,[service_name]
        ,[nofhrs]
FROM   [dbo].[quick_start_services]