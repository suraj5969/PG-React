
UPDATE [dbo].[Admin_misc]
    SET [name] = @name
        ,[value] = @value
WHERE [id] = @id