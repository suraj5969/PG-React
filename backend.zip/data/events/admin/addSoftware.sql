
INSERT INTO [dbo].[soft_client_on]
    ([soft_name],[version])
    VALUES(@soft_name,@version)
