
DELETE FROM [dbo].[soft_client_on]
    WHERE [id]=@id
