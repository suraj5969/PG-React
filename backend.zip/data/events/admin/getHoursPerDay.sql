/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [loc_id]
    ,[location]
    ,[hrs_per_days]
FROM [dbo].[Hrs_per_day]