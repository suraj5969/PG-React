
SELECT [forgot_pass] 
    from [dbo].[users] 
where [email]=@email