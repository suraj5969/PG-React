
SELECT [wordings]
    ,[value]
    ,[WORDING]
    ,[id]
FROM [dbo].[oracle_wording]