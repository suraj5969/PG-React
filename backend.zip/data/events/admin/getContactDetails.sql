/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [id]
    ,[country_name]
    ,[phone_no]
    ,[email]
FROM [dbo].[admin_contact_details]