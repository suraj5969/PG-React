/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [id]
        ,[training_name]
        ,[dateAdded]
        ,[dateModified]
        ,[HOURS]
FROM [dbo].[training_methodology]