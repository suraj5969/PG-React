
DELETE FROM [dbo].[quick_start_services]
        WHERE [service_id]=@id
