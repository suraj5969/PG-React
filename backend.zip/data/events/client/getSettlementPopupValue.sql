SELECT [no_of_licenses]
    FROM [dbo].[settlement_popup_value]
    WHERE [proposal_no] = @proposal_no