
SELECT [hrs_per_days]
  FROM [dbo].[Hrs_per_day]
  WHERE [location] = @country_name