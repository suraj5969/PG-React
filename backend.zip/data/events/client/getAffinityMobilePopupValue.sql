SELECT [num_of_users]
  FROM [dbo].[affinity_mobile_popup_value]
  WHERE [proposal_no] = @proposal_no