UPDATE [dbo].[proposal_details]
    SET [lifecycle_id] = @lifecycle_id
    WHERE [proposal_no] = @proposal_no