SELECT [id]
      ,[empower_name]
  FROM [dbo].[empower]