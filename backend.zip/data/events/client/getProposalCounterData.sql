SELECT [counter]
  FROM [dbo].[proposal_count]