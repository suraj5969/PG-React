SELECT [fname]
      ,[lname]
    FROM [dbo].[users]
    WHERE [user_id] = @user_id 