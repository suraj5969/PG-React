SELECT [hrs_required]
  FROM [dbo].[scoping_study_popup_value]
  WHERE [proposal_no] = @proposal_no