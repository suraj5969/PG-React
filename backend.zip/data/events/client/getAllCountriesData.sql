
SELECT [country_name]
  FROM [dbo].[country]