/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [email]
    FROM [dbo].[users]
    WHERE [user_id] = @user_id
