SELECT [wordings]
      ,[value]
      ,[WORDING]
    FROM [dbo].[oracle_wording]