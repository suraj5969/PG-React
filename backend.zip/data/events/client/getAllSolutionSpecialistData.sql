
SELECT [fname], [lname], [user_id], [country]
    FROM [dbo].[users]
    WHERE [solution_specialist] = 'Yes'