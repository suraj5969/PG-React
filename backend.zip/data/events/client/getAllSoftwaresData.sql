
SELECT [id],[soft_name]
  FROM [dbo].[soft_client_on]