
SELECT [DAY_NAME] ,[NO_OF_DAYS]
  FROM [dbo].[Day_Conversion]
  WHERE [DAY_ID] = @day_id