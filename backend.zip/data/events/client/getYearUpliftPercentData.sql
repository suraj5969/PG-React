SELECT [id]
      ,[name]
      ,[value]
  FROM [dbo].[Admin_misc]
  WHERE [id] = '2'